const orderModel = require("../model/orderModel")
const userModel = require("../model/userModel")
const amqp = require("amqplib/callback_api");

const placeOrder = async (email, orderDetails, done)=>{
    try{
        const user = await userModel.findOne({email:email})
        if(!user){
            return done("invalid email")
        }
        const newOrder = new orderModel({email:email, ...orderDetails})
        const data = await newOrder.save()
        amqp.connect("amqp://localhost", (err, connection) => {
            if(err){
                throw err;
            }
            connection.createChannel((err, channel)=>{
                if(err){
                    throw err;
                }
                const Queue = "createOrder"
                channel.assertQueue(Queue)
                channel.sendToQueue(Queue, Buffer.from(JSON.stringify({email:email, ...orderDetails})))
            })
            setTimeout(()=>{
                connection.close();
                process.exit(0)
            }, 500)
            return done(undefined, data)
        })
    }catch(err){
        console.log(err)
        return done(err, undefined)
    }
}

module.exports = {placeOrder}