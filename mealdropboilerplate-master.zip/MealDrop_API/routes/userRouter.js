const express = require("express")
const router = express.Router()
const userController = require("../controller/userController")

router.post("/register", (req, res)=>{
    const userDetails = req.body;
    userController.registerUser(userDetails, (err, result)=>{
        if(!err){
            res.status(201).send(result)
        }else{
            res.status(409).send("user registration failed, try again later")
        }
    })
})

router.post("/login", (req, res)=>{
    const userDetails = req.body;
    userController.loginUser(userDetails, (err, result)=>{
        if(!err){
            res.status(201).send(result)
        }else{
            res.status(404).send(err)
        }
    })    
})

module.exports = router