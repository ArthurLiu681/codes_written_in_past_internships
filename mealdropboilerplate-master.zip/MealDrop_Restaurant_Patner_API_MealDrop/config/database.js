const dotenv = require('dotenv');
dotenv.config({ path: 'MealDrop_Restaurant_Patner_API_MealDrop/config.env' });

const mongoose = require("mongoose")

const DB = process.env.Restaurant_DATABASE.replace(
  '<password>',
  process.env.DATABASE_PASSWORD
);

const conn = mongoose
  .createConnection(DB, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    // useFindAndModify: true,
  })
  
conn.asPromise()
  .then(() => console.log('Connection successfull'))
  .catch((err)=>{
    console.log(err)
  });


module.exports = conn