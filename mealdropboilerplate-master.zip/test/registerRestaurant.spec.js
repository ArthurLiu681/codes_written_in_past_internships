const { expect } = require("chai");
const supertest = require("supertest");

const meal_drop_app = require("../MealDrop_API/app");
const restaurant_partner_app = require("../MealDrop_Restaurant_Patner_API_MealDrop/server");
const delivery_agent_app = require("../MealDrop_Delivery_Agent_API/app")

describe("Testing", function () {
    it("should return status 201 while registering restaurant", function (done) {
        const restaurant = {
            id: "7890",
            name: "Northeastern dishes",
            password: "abcd",
            pendingOrder: []
        }
        supertest(restaurant_partner_app)
            .post("/api/v1/restaurants/register")
            .expect(201)
            .send(restaurant)
            .end((err, res) => {
                done(err);
            });
    });
})