const { expect } = require("chai");
const supertest = require("supertest");

const meal_drop_app = require("../MealDrop_API/server");

describe("Testing", function () {
    it("should return status 201 while registering user", function (done) {
        const user = {
            email: "user@gmail.com",
            name: "Arthur",
            password: "1234"
        }
        supertest(meal_drop_app)
            .post("/api/v1/user/register")
            .expect(201)
            .send(user)
            .end((err, res) => {
                done(err);
            });
    });
})