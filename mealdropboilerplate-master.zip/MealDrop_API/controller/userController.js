const userModel = require("../model/userModel")
const jwt = require("jsonwebtoken")

const registerUser = async (userDetails, done)=>{
    try{
        const newUser = new userModel({...userDetails})
        const result = await newUser.save();
        return done(undefined, result)    
    }catch(err){
        console.log(err)
        return done(err, undefined)
    }
}

const loginUser = async (userDetails, done)=>{
    try{
        const data = await userModel.findOne({...userDetails})
        if(!data){
            return done("wrong email or password")
        }else{
            const payload = {
                role: "USER",
                email: data.email,
                name: data.name
            }
            const token = jwt.sign(payload, process.env.AUTH_SECRET || "secret")
            return done(null, token)
        }
    }catch(err){
        console.log(err)
        return done(err, undefined)
    }
}

module.exports = {registerUser, loginUser}