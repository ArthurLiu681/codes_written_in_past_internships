const { expect } = require("chai");
const supertest = require("supertest");

const delivery_agent_app = require("../MealDrop_Delivery_Agent_API/server")

describe("Testing", function () {
    it("should return status 201 while registering agent", function (done) {
        const agent = {
            email: "agent@gmail.com",
            password: "efgh",
            name: "Arthur",
            toBePicked: []
        }
        supertest(delivery_agent_app)
            .post("/api/v1/agent/register")
            .expect(201)
            .send(agent)
            .end((err, res) => {
                done(err);
            });
    });
})