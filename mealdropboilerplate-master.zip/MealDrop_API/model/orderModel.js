const mongoose = require("mongoose")
const conn = require("../config/database")

const orderModel = new mongoose.Schema({
    email: {type: String, required: true},
    restaurantId: {type: String, required: true},
    product: {type: String, required: true},
    quantity: {type: Number, required: true}
}, {collection: "orders"})

module.exports = conn.model('orders', orderModel);