const mongoose = require("mongoose")
const conn = require("../config/database")

const restaurantSchema = new mongoose.Schema({
    id: {type: String, required: true},
    name: {type: String, required: true},
    password: {type: String, required: true},
    pendingOrder: {type: Array, required: true}
}, {collection: "restaurants"})

module.exports = conn.model("restaurant", restaurantSchema)