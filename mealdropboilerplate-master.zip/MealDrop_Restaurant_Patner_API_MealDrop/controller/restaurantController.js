const restaurantModel = require("../models/restaurantModel")
const jwt = require("jsonwebtoken")
const amqp = require('amqplib/callback_api');

const registerRestaurant = async (restaurantDetails, done)=>{
    const newRestaurant = new restaurantModel({...restaurantDetails})
    newRestaurant.save()
    .then((result)=>{
        return done(undefined, result)
    })
    .catch((err)=>{
        return done(err, undefined)
    })
}

const loginRestaurant = async (restaurantDetails, done)=>{
    try{
        const data = await restaurantModel.findOne({...restaurantDetails})
        if(!data){
            return done("wrong id or password")
        }else{
            const payload = {
                role: "RESTAURANT",
                id: data.id,
                name: data.name
            }
            const token = jwt.sign(payload, process.env.AUTH_SECRET || "secret")
            return done(null, token)
        }
    }catch(err){
        console.log(err)
        return done(err, undefined)
    }
}

const completeOrder = async (id, done)=>{
    try{
        const restaurant = await restaurantModel.findOneAndUpdate({id: id}, {$pop: {pendingOrder: -1}},{new: false})
        const data = restaurant.pendingOrder[0]
        amqp.connect("amqp://localhost", (err, connection) => {
            if(err){
                throw err;
            }
            connection.createChannel((err, channel)=>{
                if(err){  
                    throw err;
                }
                const Queue = "completedOrder"
                channel.assertQueue(Queue)
                channel.sendToQueue(Queue, Buffer.from(JSON.stringify(data)))
            })
            setTimeout(()=>{
                connection.close();
            }, 500)
            return done(undefined, data)
        })
    }catch(err){
        console.log(err)
        return done(err, undefined)
    }
}

module.exports = {registerRestaurant, loginRestaurant, completeOrder}