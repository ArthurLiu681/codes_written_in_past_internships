const app = require('./app');

const port = process.env.Restaurant_PORT || 3000;
app.listen(port, () => {
  console.log(`App stated at port ${port}`);
});

module.exports = app;
