const express = require("express")
const router = express.Router()
const restaurantController = require("../controller/restaurantController")
const jwt = require("jsonwebtoken")

router.post("/register", (req, res)=>{
    const restaurantDetails = req.body;
    restaurantController.registerRestaurant(restaurantDetails, (err, result)=>{
        if(!err){
            res.status(201).send(result)
        }else{
            res.status(409).send("restaurant registration failed, try again later")
        }
    })
})

router.post("/login", (req, res)=>{
    const restaurantDetails = req.body;
    restaurantController.loginRestaurant(restaurantDetails, (err, result)=>{
        if(!err){
            res.status(201).send(result)
        }else{
            res.status(404).send(err)
        }
    })    
})

router.post("/completeOrder", (req, res)=>{
    const token = req.headers["authorization"];
    if(!token){
        return res.status(403).send("A token is required for verification!")
    }else{
        try{
            const decoded = jwt.verify(token, process.env.AUTH_SECRET || "secret")
            restaurantController.completeOrder(decoded.id, (err, result)=>{
                if(!err){
                    res.status(201).send(result)
                }else{
                    res.status(409).send("failed to complete the order, try again later")
                }
            })
        }catch(err){
            return res.status(401).send("invalid token")
        }
    }
})

module.exports = router