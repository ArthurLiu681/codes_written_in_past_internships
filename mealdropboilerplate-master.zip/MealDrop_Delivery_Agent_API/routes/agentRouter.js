const express = require("express")
const router = express.Router()
const agentController = require("../controller/agentController")
const jwt = require("jsonwebtoken")

router.post("/register", (req, res)=>{
    const agentDetails = req.body;
    agentController.registerAgent(agentDetails, (err, result)=>{
        if(!err){
            res.status(201).send(result)
        }else{
            res.status(409).send("agent registration failed, try again later")
        }
    })
})

router.post("/login", (req, res)=>{
    const agentDetails = req.body;
    agentController.loginAgent(agentDetails, (err, result)=>{
        if(!err){
            res.status(201).send(result)
        }else{
            res.status(404).send(err)
        }
    })    
})

router.post("/pickOrder", (req, res)=>{
    const token = req.headers["authorization"];
    if(!token){
        return res.status(403).send("A token is required for verification!")
    }else{
        try{
            const decoded = jwt.verify(token, process.env.AUTH_SECRET || "secret")
            agentController.pickOrder(decoded.email, (err, result)=>{
                if(!err){
                    res.status(201).send(result)
                }else{
                    res.status(409).send("failed to pick the order, try again later")
                }
            })
        }catch(err){
            return res.status(401).send("invalid token")
        }
    }
})

module.exports = router