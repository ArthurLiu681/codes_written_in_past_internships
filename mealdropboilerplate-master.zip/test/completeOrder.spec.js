const { expect } = require("chai");
const supertest = require("supertest");

const meal_drop_app = require("../MealDrop_API/app");
const restaurant_partner_app = require("../MealDrop_Restaurant_Patner_API_MealDrop/app");
const delivery_agent_app = require("../MealDrop_Delivery_Agent_API/app")

let token = null

describe("Testing", function () {
    it("should return status 201 while logging in restaurant if request is from registered restaurant", function (done) {
        const restaurant = {
            id: "7890",
            password: "abcd",
        }
        supertest(restaurant_partner_app)
        .post("/api/v1/restaurants/login")
        .expect(201)
        .send(restaurant)
        .end((err, res) => {
            token = res.text;
            done(err);
        });
    });
    it("should return status 201 while completing order if request is from registered restaurant", function (done) {
        supertest(restaurant_partner_app)
        .post("/api/v1/restaurants/completeOrder")
        .set("Authorization", token)
        .expect(201)
        .send()
        .end((err, res)=>{
            console.log(err)
            done(err);
        })
    });
    it("should return status 404 while logging in restaurant if request is from unregistered restaurant", function (done) {
        const restaurant = {
            email: "restaurant@gmail.com",
            password: "2345"
        }
        supertest(restaurant_partner_app)
        .post("/api/v1/restaurants/login")
        .expect(404)
        .send(restaurant)
        .end((err, res) => {
            done(err);
        });
    });
})