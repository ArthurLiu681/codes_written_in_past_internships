/* Give the config parameters to establish database connectivity*/
module.exports = {
    HOST: "",
    USER: "",
    PASSWORD: "",
    DB: ""
  };