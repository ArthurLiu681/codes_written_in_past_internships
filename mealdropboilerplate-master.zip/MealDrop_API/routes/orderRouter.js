const express = require("express")
const router = express.Router()
const orderController = require("../controller/orderController")
const jwt = require("jsonwebtoken")

router.post("/", (req, res)=>{
    const token = req.headers["authorization"];
    if(!token){
        return res.status(403).send("A token is required for verification!")
    }else{
        try{
            const decoded = jwt.verify(token, process.env.AUTH_SECRET || "secret")
            const orderDetails = req.body;
            orderController.placeOrder(decoded.email, orderDetails, (err, result)=>{
                if(!err){
                    res.status(201).send(result)
                }else{
                    res.status(409).send(err)
                }
            })
        }catch(err){
            console.log(err)
            return res.status(401).send("invalid token")
        }
    }
})

module.exports = router