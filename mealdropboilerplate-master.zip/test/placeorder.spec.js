const { expect } = require("chai");
const supertest = require("supertest");

const meal_drop_app = require("../MealDrop_API/app");
const restaurant_partner_app = require("../MealDrop_Restaurant_Patner_API_MealDrop/app");
const delivery_agent_app = require("../MealDrop_Delivery_Agent_API/app")

let token = null;
const order = {
    restaurantId: "7890",
    product: "fish",
    quantity: 4
}

describe("Testing", function () {
    it("should return status 201 while logging in user and placing order if request is from registered user", function (done) {
        const user = {
            email: "user@gmail.com",
            password: "1234"
        }
        supertest(meal_drop_app)
            .post("/api/v1/user/login")
            .expect(201)
            .send(user)
            .end((err, res) => {
                token = res.text;
                done(err);
            });
        })
    it("should return status 201 while logging in user and placing order if request is from registered user", function (done) {
        supertest(meal_drop_app)
            .post("/api/v1/order/")
            .set("Authorization", token)
            .expect(201)
            .send(order)
            .end((err, res)=>{
                done(err);
            })
    });
    it("should return status 404 while logging in user if request is from unregistered user", function (done) {
        const user = {
            email: "user@gmail.com",
            password: "2345"
        }
        supertest(meal_drop_app)
            .post("/api/v1/user/login")
            .expect(404)
            .send(user)
            .end((err, res) => {
                done(err);
            });
    });
})