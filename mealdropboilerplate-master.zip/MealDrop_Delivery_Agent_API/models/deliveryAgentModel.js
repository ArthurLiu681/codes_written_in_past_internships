const mongoose = require("mongoose")
const conn = require("../config/database")

const agentModel = new mongoose.Schema({
    email: {type: String, required: true},
    password: {type: String, required: true},
    name: {type: String, required: true},
    toBePicked: {type: Array, required: true}
}, {collection: "agents"})

module.exports = conn.model('agents', agentModel);