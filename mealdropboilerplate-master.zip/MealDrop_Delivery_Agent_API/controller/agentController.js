const agentModel = require("../models/deliveryAgentModel")
const jwt = require("jsonwebtoken")

const registerAgent = async (agentDetails, done)=>{
    const newAgent = new agentModel({...agentDetails})
    const result = await newAgent.save();
    return done(undefined, result)    
}

const loginAgent = async (agentDetails, done)=>{
    try{
        const data = await agentModel.findOne({...agentDetails})
        if(!data){
            return done("wrong email or password")
        }else{
            const payload = {
                role: "AGENT",
                email: data.email,
                name: data.name
            }
            const token = jwt.sign(payload, process.env.AUTH_SECRET || "secret")
            return done(null, token)
        }
    }catch(err){
        console.log(err)
        return done(err, undefined)
    }
}

const pickOrder = async (email, done)=>{
    try{
        const agent = await agentModel.findOneAndUpdate({email: email}, {$pop: {toBePicked: -1}})
        const data = agent.toBePicked[0]
        return done(undefined, data)
    }catch(err){
        console.log(err)
        return done(err, undefined)
    }
}

module.exports = {registerAgent, loginAgent, pickOrder}