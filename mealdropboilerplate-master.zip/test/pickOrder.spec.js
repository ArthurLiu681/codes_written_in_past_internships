const { expect } = require("chai");
const supertest = require("supertest");

const meal_drop_app = require("../MealDrop_API/app");
const restaurant_partner_app = require("../MealDrop_Restaurant_Patner_API_MealDrop/app");
const delivery_agent_app = require("../MealDrop_Delivery_Agent_API/app")

let token = null;

describe("Testing", function () {
    it("should return status 201 while logging in agent if request is from registered agent", function (done) {
        const agent = {
            email: "agent@gmail.com",
            password: "efgh",
        }
        supertest(delivery_agent_app)
            .post("/api/v1/agent/login")
            .expect(201)
            .send(agent)
            .end((err, res) => {
                token = res.text;
                done(err);
            });
    });
    it("should return status 201 while picking order if request is from registered agent", function (done) {
        supertest(delivery_agent_app)
            .post("/api/v1/agent/pickOrder")
            .set("Authorization", token)
            .expect(201)
            .send()
            .end((err, res)=>{
                done(err);
            });
    });
    it("should return status 404 while logging in agent if request is from unregistered agent", function (done) {
        const agent = {
            email: "agnt@gmail.com",
            password: "2345"
        }
        supertest(delivery_agent_app)
            .post("/api/v1/agent/login")
            .expect(404)
            .send(agent)
            .end((err, res) => {
                done(err);
            });
    });
})