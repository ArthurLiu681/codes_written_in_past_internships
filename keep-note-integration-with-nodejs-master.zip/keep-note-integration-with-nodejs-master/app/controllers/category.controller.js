const categoryService = require("../service/category.service.js");

/* Call the create method of categoryService object and return the result back*/
exports.create = null;

/* Call the getAll method of categoryService object and return the result back */
exports.findAll = null;

/* Call the findById method of categoryService object and return the result back */
exports.findOne = null;

/* Call the updateById method of categoryService object and return the result back */
exports.update = null;

/* Call the remove method of categoryService object and return the result back */
exports.delete = null;

/* Call the removeAll method of categoryService object and return the result back */
exports.deleteAll = null;