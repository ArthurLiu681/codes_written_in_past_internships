const mongoose = require("mongoose")
const conn = require("../config/database")

const userModel = new mongoose.Schema({
    email: {type: String, required: true},
    name: {type: String, required: true},
    password: {type: String, required: true}
}, {collection: "users"})

module.exports = conn.model('users', userModel);